#!/bin/sh
# Downloads the three.js files into the app so the game runs fully offline.
mkdir -p app/src/main/assets/lib
curl -fL https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js -o app/src/main/assets/lib/three.min.js
curl -fL https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js -o app/src/main/assets/lib/GLTFLoader.js
curl -fL https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/utils/SkeletonUtils.js -o app/src/main/assets/lib/SkeletonUtils.js
